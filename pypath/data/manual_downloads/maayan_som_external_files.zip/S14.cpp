void RandomIslandsNets()
{
      INTERACTION* tempNode;
      INTERACTION* tempNode1;
      INTERACTION* tempNode2;
      ofstream out;
      int randomNumber;
      char fileName[100];
      char tempStr[100];
      int i, j;
 
      DumpNetwork("random_net0.sig");
      for (i = 1; i <= 100;)
      {
            sprintf(fileName, "random_net%d.sig", i);
            out.open(fileName);
            tempNode1 = InteractionsList;
            while (tempNode1)
            {
                  randomNumber = GetRandomNumber(NumberOfInteractions);
                  tempNode2 = InteractionsList;
                  for (j = 0; j < randomNumber; j++)
                  {
                        tempNode2 = tempNode2->next;
                  }
                  if ((tempNode1 != tempNode2) && 
		      (strcmp(tempNode1->source, tempNode2->target)) &&
                      (strcmp(tempNode2->source, tempNode1->target)) && 
		      (ThereIsNoLinkAlready(tempNode1, tempNode2)))
                  {
                        strcpy(tempStr, tempNode1->target);
                        strcpy(tempNode1->target, tempNode2->target);
                        strcpy(tempNode2->target, tempStr);
                  }
                  tempNode1 = tempNode1->next;
            }
            tempNode = InteractionsList;
            while (tempNode)
            {
                 out << tempNode->source << " ";
		 out << tempNode->sourceAccHuman << " ";
		 out << tempNode->sourceAccMouse << " ";
		 out << tempNode->sourceType << " ";
		 out << tempNode->sourceLocation << " ";
		 out << tempNode->target << " ";
                 out << tempNode->targetAccHuman << " ";
		 out << tempNode->targetAccMouse << " ";
		 out << tempNode->targetType << " ";
		 out << tempNode->targetLocation << " ";
		 out << tempNode->effect << " ";
		 out << tempNode->typeOfInteraction << " ";
		 out << tempNode->pmid <<  endl; 
                 tempNode = tempNode->next;
            }
            FreeNetwork();
            out.close();
            LoadNetwork(fileName);
            if (CountIslands() == 1)
            {
                  i++;
            }
            else
            {
                  FreeNetwork();
                  sprintf(fileName, "random_net%d.sig", i - 1);
                  LoadNetwork(fileName);
            }
      }
}
