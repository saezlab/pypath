double ComputeCC(void)
{
      MOLECULE* tempNode;
      MOLECULE* neighborNode;
      double cc;
      int linksFound;
      int i, j, k;
 
      tempNode = MoleculesList;
      cc = 0;
      while (tempNode)
      {
            linksFound = 0;
            for (i = 0; i < tempNode->linksCount; i++)
            {
                neighborNode = GetNodeBasedOnNumber(tempNode->linksTo[i]);
                for (k = 0; k < neighborNode->linksCount; k++)
                {
                    for (j = 0; j < tempNode->linksCount; j++)
                    {
                        if (neighborNode->linksTo[k] == tempNode->linksTo[j])
                        {
                            linksFound++;
                        }
                    }
                }  
            }
 
            if ((tempNode->linksCount * (tempNode->linksCount - 1) / 2) && 
			    (linksFound))
            {
                  linksFound /= 2;
                  cc += linksFound / 
                        ((tempNode->linksCount * 
			  (tempNode->linksCount - 1.0) / 2.0));
                  tempNode->cc = linksFound / 
                        ((tempNode->linksCount * 
			  (tempNode->linksCount - 1.0) / 2.0));
            }
            else
            {
                  tempNode->cc = 0;
            }
            tempNode = tempNode->next;
    }
    cc = cc / NumberOfMolecules;
    return cc;
}
