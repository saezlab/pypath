void ExpandAllLigands(void)
{
      MOLECULE* startNode;
      int i, k;
      ofstream out;
      int count = 0;
      char fileName[100];

      startNode = MoleculesList;
      k = 0;
      while (startNode)
      {
            if (!strcmp(startNode->moleculeType, "Ligand"))
            {     
                  ClearVisitedFlagForAllMolecules();
                  for (i = 1; i <= 15; i++)
                  {     
                        ExpandSim(startNode, i, 0);
                        sprintf(fileName, "%s_sub_net_depth%d.sig", startNode->name, i);
                        startNode->visited = 1;
                        DumpAllVisited(fileName);
                  }
            }
            startNode = startNode->next;
      }
}

int ExpandSim (MOLECULE* tempNode, int depth, int count)
{
      MOLECULE* tempNode1;
      int i;
      
      tempNode->visited = depth;
      if (depth == 0)
      {
            return count;
      }
      for (i = 0; i < tempNode->linksCount; i++)
      {
            tempNode1 = GetNodeBasedOnNumber(tempNode->linksTo[i]);
            if (((tempNode1->visited == 0) || (tempNode1->visited < depth)) &&                        (DirectionOK(tempNode, tempNode1)))
            {
                  count = ExpandSim(tempNode1, depth - 1, count + 1);
            }
      }
      return count;
}
