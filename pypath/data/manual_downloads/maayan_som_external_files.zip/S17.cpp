void FindFeedbackLoops (MOLECULE* sourceNode, MOLECULE* tempNode, 
		int sizeWeLookFor, int howDeep, int* listSoFar)
{
	MOLECULE* localNode;
	int i;

	localNode = tempNode;

	if (howDeep == sizeWeLookFor)
	{
		if (!strcmp(tempNode->name, sourceNode->name))
		{
			if (IsItNegativeLoop(listSoFar, sizeWeLookFor - 1))
			{
				NegativeFeedbackLoops[sizeWeLookFor]++;
			}
			else
			{
				PositiveFeedbackLoops[sizeWeLookFor]++;

			}
			FeedbackLoops[sizeWeLookFor]++;
		}

	}
	else if ((howDeep > 1) && (!strcmp(tempNode->name, sourceNode->name)))
	{
		return;
	}
	else
	{
		for (int i = 0; i < tempNode->linksCount; i++)
		{	
			localNode = GetNodeBasedOnNumber(tempNode->linksTo[i]);

			if (localNode && 
			   (NotAlreadyInList(listSoFar, howDeep, 
					     localNode->number) && 
			    (DirectionOK(tempNode, localNode))))
			{
				listSoFar[howDeep - 1] = localNode->number;
				FindFeedbackLoops(sourceNode, localNode, 
						sizeWeLookFor, howDeep + 1, 
						listSoFar);
			}
		}
	}	
}
