void CreateReducedNetworks() 
{
	INTERACTION* tempNode;
	MOLECULE* tempNode1;
	MOLECULE* tempNode2;
	ofstream out;
	int numberOfInteractions = 0;
	int j;
	char fileName[100];

	for (j = 1; j < 50; j++)
	{
		numberOfInteractions = 0;
		sprintf(fileName, "reduced_net%d.sig", j);
		out.open(fileName);

		tempNode = InteractionsList;

		while (tempNode)
		{
			tempNode1 = GetNodeBasedOnName(tempNode->source);
			tempNode2 = GetNodeBasedOnName(tempNode->target);

			if ((tempNode1->linksCount <= j) && 
			    (tempNode2->linksCount <= j))
			{
				out << tempNode->source << " ";
			        out << tempNode->sourceAccHuman << " ";
			        out << tempNode->sourceAccMouse << " ";
			        out << tempNode->sourceType << " ";
			        out << tempNode->sourceLocation << " ";
			        out << tempNode->target << " ";
			        out << tempNode->targetAccHuman << " ";
			        out << tempNode->targetAccMouse << " ";
				out << tempNode->targetType << " ";
			        out << tempNode->targetLocation << " ";
			        out << tempNode->effect << " ";
			        out << tempNode->typeOfInteraction << " ";
			        out << tempNode->pmid << endl;
				tempNode->flag = 1;
			}

			tempNode = tempNode->next;
		}
		out.close();
	}
}
