void FindBifans (MOLECULE* sourceNode, MOLECULE* tempNode, int sizeWeLookFor, int howDeep, int* listSoFar, int flipFlag)
{
	MOLECULE* localNode;
	int i;

	localNode = tempNode;
	if (howDeep == sizeWeLookFor)
	{
		if (!strcmp(tempNode->name, sourceNode->name))
		{
			Bifans[sizeWeLookFor]++;
		}
	}
	else if ((howDeep > 1) && (!strcmp(tempNode->name, sourceNode->name)))
	{
		return;
	}
	else
	{
		for (int i = 0; i < tempNode->linksCount; i++)
		{	
			localNode = GetNodeBasedOnNumber(tempNode->linksTo[i]);

			if (((localNode && 
			     (NotAlreadyInList(listSoFar, howDeep, 
					       localNode->number))) &&
			     ((flipFlag && 
			      (OppositeDirectionOK(tempNode, localNode))) ||
			     ((!flipFlag) && 
			      (DirectionOK(tempNode, localNode))))) &&
			     (!((localNode == sourceNode) && 
				(howDeep + 1 != sizeWeLookFor))))
			{
				listSoFar[howDeep] = localNode->number;
				if (flipFlag)
				{
					FindBifans(sourceNode, localNode, 
					sizeWeLookFor, howDeep + 1, 
					listSoFar, 0);
				}
				else
				{
					FindBifans(sourceNode, localNode, 
				  	sizeWeLookFor, howDeep + 1, 
					listSoFar, 1);
				}
			}
		}
	}	
}
