double ComputeAvgPathLength(void)
{     
      MOLECULE* tempNode;
      double arrayOfAvgPathLengths[15000];
      int cc = 0;
      int i, j, k;
      double avg;
      ofstream out;

      out.open("out.txt");

      //Floyd and Warshall's algorithm see
      tempNode = MoleculesList;
      
      //this only works if the network is fully connected
      for (i=0; i< NumberOfMolecules; i++)
      {
            for (j=0; j < NumberOfMolecules; j++)
            {
                  A[i][j] = 9999999;
            }
      }

      for (i=0; i < NumberOfMolecules; i++)
      {
            for (j=0; j < NumberOfMolecules; j++)
            {
                  tempNode = GetNodeBasedOnNumber(i+1);
                  for (k = 0; k < tempNode->linksCount; k++)
                  {
                        if (tempNode->linksTo[k] == (j+1))
                        {
                              A[i][j] = 1;
                        }
                  }
            }
      }
 
      for (i=0; i < NumberOfMolecules; i++)
      {
            A[i][i] = 0;              // no self cycle
      }
 
      for (k = 0; k < NumberOfMolecules; k++)
      {
            for (i = 0; i < NumberOfMolecules; i++)
            {
                  for (j = 0; j < NumberOfMolecules; j++)
                  {
                        if (((A[i][k] + A[k][j]) < A[i][j]) && ((A[i][k] + A[k][j]) > 0))
                        {
                              A[i][j] = A[i][k] + A[k][j];
                        }
                   }
            }
      }
 
      // compute averages
      for (i=0; i < NumberOfMolecules; i++)
      {
            avg = 0;
            for (j=0; j < NumberOfMolecules; j++)
            {
                  avg += A[i][j];   
            }
            arrayOfAvgPathLengths[i] = avg / (NumberOfMolecules - 1);
      }
      avg = 0;
      for (i=0; i < NumberOfMolecules; i++)
      {
            avg += arrayOfAvgPathLengths[i];
      }
      
      avg /= (NumberOfMolecules - 1);
      return avg;
}
