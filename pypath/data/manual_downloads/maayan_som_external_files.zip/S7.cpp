void MachineCount()
{
      MOLECULE* tempNode;     
      ofstream out;
      ofstream machines;
      int countToTranscription = 0;
      int countToCentral = 0;
      int countToCytoskeleton = 0;
      int countToTranslation = 0;
      int countToTransmission = 0;
      int countToVesicles = 0;
      int countToApoptosis = 0;
      int countMembrane = 0;
      int other = 0;
      int input = 0;
      int total = 0;
            
      out.open("machines_counts.htm");
      machines.open("machines.txt");
 
      out << "<html><body><table>";

      tempNode = MoleculesList;

      while (tempNode)
      {
            if ((!strcmp(tempNode->location, "ER")) || 
		(!strcmp(tempNode->location, "Ribosomes")))
            {
                  tempNode->machine = TRANSLATION;
                  countToTranslation++;
                  machines << tempNode->name << " -> " << "Translation" << endl;
            }
            else if (!strcmp(tempNode->moleculeType, "Channel"))
            {
                  tempNode->machine = TRANSMISSION;
                  countToTransmission++;
                  machines << tempNode->name << " -> ";
		  machines << "Electrical Response System" << endl;
            }
            else if (!strcmp(tempNode->location, "Vesicles"))
            {
                  tempNode->machine = SECRETION;
                  countToVesicles++;
                  machines << tempNode->name << " -> ";
		  machines << "Secretory Apparatus" << endl;
            }
            else if (!strcmp(tempNode->moleculeType, "Cytoskeleton"))
            {
                  tempNode->machine = CYTOSKELETON;
                  countToCytoskeleton++;
                  machines << tempNode->name << " -> ";
		  machines << "Motility Apparatus" << endl;
            }
            else if (!strcmp(tempNode->location, "Nucleus"))
            {
                  tempNode->machine = TRANSCRIPTION;
                  countToTranscription++;
                  machines << tempNode->name << " -> ";
		  machines << "Transcription" << endl;
            }
            else if ((!strcmp(tempNode->moleculeType, "Ligand")) || 
                     (!strcmp(tempNode->location, "Extracellular")))
            {
                  tempNode->machine = EXTRACELLULAR_LIGANDS;
                  input++;
                  machines << tempNode->name << " -> ";
		  machines << "Extracellular" << endl;
            }
            else if (!strcmp(tempNode->location, "Membrane"))
            {
                  tempNode->machine = TRANSMEMBRANE;
                  countMembrane++;
                  machines << tempNode->name << " -> ";
                  machines << "Membrane Receptors & Proteins" << endl;
            }
            else
            {
                  tempNode->machine = CENTRAL_SIGNALING;
                  countToCentral++;
                  machines << tempNode->name << " -> ";
                  machines << "Central Signaling Network" << endl;
            }

            tempNode = tempNode->next;
      }
      out << "Central Signaling: " << countToCentral << "<br>" << endl;
      out << "Ion Channels: " << countToTransmission << "<br>" << endl;
      out << "Vesicles: " << countToVesicles << "<br>" << endl;
      out << "Cytoskeleton: " << countToCytoskeleton << "<br>" << endl;
      out << "Nucleus: " << countToTranscription << "<br>" << endl;
      out << "Ribosomes and ER: " << countToTranslation << "<br>" << endl;
      out << "Ligands: " << input << "<br>" << endl;
      out << "Membrane: " << countMembrane << "<br>" << endl;
      out << "</body></html>";

      out.close();
      machines.close();
}
