void FindFeedforwardLoops (MOLECULE* sourceNode, MOLECULE* tempNode, int sizeWeLookFor, int howDeep, int* listSoFar, int directionFlag)
{
	MOLECULE* localNode;
	int i;
	int flag;
	int symmetricFlag;

	localNode = tempNode;

	if (howDeep == sizeWeLookFor)
	{
		if (!strcmp(tempNode->name, sourceNode->name))
		{
			if (directionFlag == 2)
			{
				if (IsItNegativeFeedforwardLoop(listSoFar, sizeWeLookFor - 1))
				{
					if (IsItSymmetric(listSoFar, sizeWeLookFor - 1))
					{
						NegativeFeedforwardLoops[sizeWeLookFor]++;
						symmetricFlag = 1;
					}
					else
					{
						NegativeFeedforwardLoops[sizeWeLookFor]++;
						NegativeFeedforwardLoops[sizeWeLookFor]++;
						symmetricFlag = 0;
					}
				}
				else
				{
					if (IsItSymmetric(listSoFar, sizeWeLookFor - 1))
					{
						PositiveFeedforwardLoops[sizeWeLookFor]++;
						symmetricFlag = 1;
					}
					else
					{
						PositiveFeedforwardLoops[sizeWeLookFor]++;
						PositiveFeedforwardLoops[sizeWeLookFor]++;
						symmetricFlag = 0;
					}
					
				}

				FeedforwardLoops[sizeWeLookFor]++;

				if (!symmetricFlag)
				{
					FeedforwardLoops[sizeWeLookFor]++;
				}
			}
		}
	}
	else if ((howDeep > 1) && (!strcmp(tempNode->name, sourceNode->name)))
	{
		return;
	}
	else
	{
		if (tempNode->linksCount > 1)
		{
			for (int i = 0; i < tempNode->linksCount; i++)
			{	
				localNode = GetNodeBasedOnNumber(tempNode->linksTo[i]);
				flag  = 0;			
				if ((OppositeDirectionOK(tempNode, localNode)) && (NotAlreadyInList(listSoFar, howDeep, localNode->number)) && (directionFlag == 1) && (howDeep != 1) && (strcmp(localNode->name, sourceNode->name)))
				{
					flag = 2;
				}
				else if ((DirectionOK(tempNode, localNode)) && (NotAlreadyInList(listSoFar, howDeep, localNode->number)) && (directionFlag == 1))
				{
					flag = 1;
				}	
				else if (NotAlreadyInList(listSoFar, howDeep, localNode->number) && (DirectionOK(tempNode, localNode)) && (directionFlag == 0))
				{
					flag = 1; 
				}
				else if ((OppositeDirectionOK(tempNode, localNode)) && (NotAlreadyInList(listSoFar, howDeep, localNode->number)) && (directionFlag == 2))
				{
					flag = 2;
				}

				if (flag)
				{
					listSoFar[howDeep] = localNode->number;
					FindFeedforwardLoops(sourceNode, localNode, sizeWeLookFor, howDeep + 1, listSoFar, flag);
				}
			}	
		}
	}	
}
