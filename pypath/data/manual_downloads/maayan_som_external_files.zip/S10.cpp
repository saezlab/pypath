void AnalyzeLignadInducedSubnetworks(void)
{
      int i;
      int j;
      char fileName[100];
      char name[100][100];
      int k = 0;
      MOLECULE* startNode;
 
      startNode = MoleculesList;
      k = 0;
      k++;
      strcpy(name[k], "GLUTAMATE");
      k++;
      strcpy(name[k], "NE");
      k++;
      strcpy(name[k], "BDNF");
      k++;

      for (j = 0; j < k; j++)
      {
            out << "<tr><td>" << name[j] << "</td></tr>";
            for (i = 2; i <= 10; i++)
            {     
                  sprintf(fileName, "%s_sub_net_depth%d.sig", name[j], i);
                  LoadNetwork(fileName);        
                  CountFeedbackLoops(3, 4);
                  CountScaffolds();
                  CountBifans();
                  CountFeedforwardLoops(3, 4);
                        
                  out << "<tr><td>" << i;
		  out << "</td><td>" << NumberOfInteractions;
		  out << "</td><td>" << NumberOfMolecules;
                  out << "</td><td>" << CountPositivesEffects();
                  out << "</td><td>" << CountNegativesEffects();
                  out << "</td><td>" << CountNeutralsEffects();
                  out << "</td><td>" << ComputeCC();
                  out << "</td><td>" << ComputeGC();
		  out << "</td><td>" << ComputeAvgPathLength();
                  out << "</td><td>" << CountIslands();
		  out << "</td><td>" << FeedbackLoops[3];
                  out << "</td><td>" << FeedbackLoops[4];
                  out << "</td><td>" << PositiveFeedbackLoops[3];
                  out << "</td><td>" << PositiveFeedbackLoops[4];
                  out << "</td><td>" << NegativeFeedbackLoops[3];
                  out << "</td><td>" << NegativeFeedbackLoops[4];
                  out << "</td><td>" << Scaffolds[3];
                  out << "</td><td>" << Bifans[4];
                  out << "</td><td>" << FeedforwardLoops[3];
                  out << "</td><td>" << FeedforwardLoops[4];
                  out << "</td><td>" << PositiveFeedforwardLoops[3];
                  out << "</td><td>" << PositiveFeedforwardLoops[4];
		  out << "</td><td>" << NegativeFeedforwardLoops[3];
                  out << "</td><td>" << NegativeFeedforwardLoops[4];
                  out << "</td></tr>" << endl;
                  FreeMotifs();           
                  FreeNetwork();
            }
      }                 
      out << "</tr>" << endl;
      out << "</table></body></html>";
      out.close();
}
