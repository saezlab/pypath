void PajekFileWithFixedSpots()
{
      ofstream graph;
      MOLECULE* tempNode;
      INTERACTION* tempInteraction;    
      graph.open("fix_sptos.net");
      char colorAndShape[100];
      char moleculeTypeIndex;
      double x, y;

      SortMoleculeList();
      ComputeBestLocations();
      graph << "*Vertices    " << NumberOfMolecules << endl;
      tempNode = MoleculesList;
      while (tempNode)
      {
            moleculeTypeIndex = GetMoleculeTypeIndex(tempNode->moleculeType);
            GetColorAndShape(moleculeTypeIndex, colorAndShape);
            x = (double) tempNode->bestXLocation;
            x /= 120;
            y = (double) tempNode->bestYLocation;
            y /= 120;
 
            if (!strcmp(tempNode->moleculeType, "Ligand"))
            {
                  if (!strcmp("GLUTAMATE", tempNode->name))
                  {
                        graph << tempNode->number << "  " << "\"" << tempNode->name << "\" " << x << " " << y << " 1.0 triangle " << "x_fact " << GetNodeSize(tempNode) << " y_fact " << GetNodeSize(tempNode) << " ic Orange" << endl;
                  }
                  else
                  {
                        graph << tempNode->number << "  " << "\"\" " << x << " " << y << " 1.0 triangle " << "x_fact " << GetNodeSize(tempNode) << " y_fact " << GetNodeSize(tempNode) << " ic Red" << endl;
                  }
            }
            else if (!strcmp(tempNode->moleculeType, "Cytoskeleton"))
            {
                  {
                        graph << tempNode->number << "  " << "\"" << tempNode->name << "\" " << x << " " << y << " 1.0 triangle " << "x_fact " << GetNodeSize(tempNode) << " y_fact " << GetNodeSize(tempNode)  << " ic Yellow" << endl;
                  }
                  else
                  {
                        graph << tempNode->number << "  " << "\"\" " << x << " " << y << " 1.0 triangle " << "x_fact " << GetNodeSize(tempNode) << " y_fact " << GetNodeSize(tempNode)  << " ic LightYellow" << endl;
                  }
            }
            else if (!strcmp(tempNode->location, "Nucleus"))
            {
                  if (!strcmp("CREB", tempNode->name))
                  {
                        graph << tempNode->number << "  " << "\"" << tempNode->name << "\" " << x << " " << y << " 1.0 triangle " << "x_fact " << GetNodeSize(tempNode) << " y_fact " << GetNodeSize(tempNode)  << " ic Green" << endl;
                  }
                  else
                  {
                        graph << tempNode->number << "  " << "\"\" " << x << " " << y << " 1.0 triangle " << "x_fact " << GetNodeSize(tempNode) << " y_fact " << GetNodeSize(tempNode)  << " ic OliveGreen" << endl;
                  }
            }
            else if ((!strcmp(tempNode->location, "ER")) || (!strcmp(tempNode->location, "Ribosomes")))
            {
                  graph << tempNode->number << "  " << "\"\" " << x << " " << y << " 1.0 triangle " << "x_fact " << GetNodeSize(tempNode) << " y_fact " << GetNodeSize(tempNode)  << " ic Purple" << endl;
            }
            else if (!strcmp(tempNode->moleculeType, "Channel"))
            {
                  if (!strcmp("AMPAR", tempNode->name))
                  {
                        graph << tempNode->number << "  " << "\"" << tempNode->name << "\" " << x << " " << y << " 1.0 triangle " << "x_fact " << GetNodeSize(tempNode) << " y_fact " << GetNodeSize(tempNode)  << " ic RedViolet" << endl;
                  }
                  else
                  {
                        graph << tempNode->number << "  " << "\"\" " << x << " " << y << " 1.0 triangle " << "x_fact " << GetNodeSize(tempNode) << " y_fact " << GetNodeSize(tempNode)  << " ic RedViolet" << endl;
                  }
            }
            else if (!strcmp(tempNode->location, "Membrane"))
            {
                  if (!strcmp("NMDAR", tempNode->name))
                  {
                        graph << tempNode->number << "  " << "\"" << tempNode->name << "\" " << x << " " << y << " 1.0 triangle " << "x_fact " << GetNodeSize(tempNode) << " y_fact " << GetNodeSize(tempNode)  << " ic Green" << endl;
                  }
                  else
                  {
                        graph << tempNode->number << "  " << "\"\" " << x << " " << y << " 1.0 triangle " << "x_fact " << GetNodeSize(tempNode) << " y_fact " << GetNodeSize(tempNode)  << " ic LightGreen" << endl;
                  }
            }
            else if (!strcmp(tempNode->location, "Vesicles"))
            {
                  if (!strcmp("SYNTAXIN", tempNode->name))
                  {
                        graph << tempNode->number << "  " << "\"" << tempNode->name << "\" " << x << " " << y << " 1.0 triangle " << "x_fact " << GetNodeSize(tempNode) << " y_fact " << GetNodeSize(tempNode)  << " ic Maroon" << endl;
                  }
                  else
                  {
                        graph << tempNode->number << "  " << "\"\" " << x << " " << y << " 1.0 triangle " << "x_fact " << GetNodeSize(tempNode) << " y_fact " << GetNodeSize(tempNode)  << " ic Maroon" << endl;
                  }
            }
            else if (!strcmp(tempNode->location, "Cytosol"))
            {
                  if ((!strcmp("PKA", tempNode->name)) || (!strcmp("PKC", tempNode->name)))
                  {
                        graph << tempNode->number << "  " << "\"" << tempNode->name << "\" " << x << " " << y << " 1.0 triangle " << "x_fact " << GetNodeSize(tempNode) << " y_fact " << GetNodeSize(tempNode)  << " ic Blue" << endl;
                  }
                  else
                  {
                        graph << tempNode->number << "  " << "\"\" " << x << " " << y << " 1.0 triangle " << "x_fact " << GetNodeSize(tempNode) << " y_fact " << GetNodeSize(tempNode)  << " ic CornflowerBlue" << endl;
                  }
            }
            else
            {
                  graph << tempNode->number << "  " << "\"\" " << x << " " << y << " 1.0 triangle " << "x_fact " << GetNodeSize(tempNode) << " y_fact " << GetNodeSize(tempNode)  << " ic CornflowerBlue" << endl;
            }
            
            tempNode = tempNode->next;
      }
      graph << "*Arcs" << endl;
      tempInteraction = InteractionsList;
      while (tempInteraction)
      { 
            tempNode = GetNodeBasedOnName(tempInteraction->source);
            tempNode1 = GetNodeBasedOnName(tempInteraction->target);
            if (!strcmp(tempInteraction->effect, "+"))
            {
                  graph << "   " << GetNumberBasedOnString(tempInteraction->source) << "    ";
                  graph << GetNumberBasedOnString(tempInteraction->target) << "    " <<  "1 c LightGreen" << endl;
            }
            else if (!strcmp(tempInteraction->effect, "_"))
            {
                  graph << "   " << GetNumberBasedOnString(tempInteraction->source) << "    ";
                  graph << GetNumberBasedOnString(tempInteraction->target) << "    " <<  "1 c Pink" << endl;
            }
            else if (!strcmp(tempInteraction->effect, "0"))
            {
                  graph << "   " << GetNumberBasedOnString(tempInteraction->source) << "    ";
                  graph << GetNumberBasedOnString(tempInteraction->target) << "    " <<  "1 c Cyan" << endl;

            }
            tempInteraction = tempInteraction->next;
      }
      graph.close();
}
