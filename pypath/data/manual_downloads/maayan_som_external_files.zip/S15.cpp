void BuildSubNet(char* source, char* target, int steps)
{
      MOLECULE* tempNode;
      ofstream out;
      ofstream out1;
      int negatives = 0;
      int positives = 0;
      int listSoFar[20];
      int i;
      char fileName[200];
      char dummy[20];
 
      for (i = steps; i <= steps; i++)
      {
            tempNode = MoleculesList;
            while (tempNode)
            {
                  if (!strcmp(tempNode->name, source))
                  {
                        listSoFar[0] = tempNode->number;
                        strcpy(fileName, "to_");
                        strcat(fileName, target);
                        strcat(fileName, "_");
                        strcat(fileName, tempNode->name);
                        strcat(fileName, "_");
                        strcat(fileName, itoa(steps, dummy, 10));
                        strcat(fileName, ".sig");
                        out1.open(fileName);
                        ClearInteractionsFlag();
                        IndexOfGlobalList = 0;
                        CountNumberOfPathwaysToOutputAndDump(out1, 
					target, tempNode, i, 1, listSoFar);
                        AddInteractionsForFeedbackLoops(out1);
                        out1.close();
                  }
                  tempNode = tempNode->next;
            }
      }
}
 
void CountNumberOfPathwaysToOutputAndDump(ofstream &out1, char* targetName, MOLECULE* tempNode, int sizeWeLookFor, int howDeep, int* listSoFar)
{
      MOLECULE* localNode;
      MOLECULE* tempNode3;
      MOLECULE* tempNode4;
      INTERACTION* tempInt;
      
      localNode = tempNode;
      if ((howDeep <= sizeWeLookFor) && (!strcmp(tempNode->name, targetName)))
      {
            for (int i = 0; i < howDeep - 1; i++)
            {
                  tempNode3 = GetNodeBasedOnNumber(listSoFar[i]);
                  tempNode4 = GetNodeBasedOnNumber(listSoFar[i + 1]);
                  tempInt = GetInteraction(tempNode3->name, tempNode4->name);
                  if (!tempInt)
                  {
                        tempInt = GetInteraction(tempNode4->name, 
					tempNode3->name);
                  }
                  if (!tempInt->flag)
                  {
                        out1 << tempInt->source << " ";
		        out1 << tempInt->sourceAccHuman << " ";
		        out1 << tempInt->sourceAccMouse << " ";
		        out1 << tempInt->sourceLocation << " ";
		        out1 << tempInt->sourceType << " ";
		        out1 << tempInt->target << " ";
		        out1 << tempInt->targetAccHuman << " ";
		        out1 << tempInt->targetAccMouse << " ";
		        out1 << tempInt->targetType << " ";
		        out1 << tempInt->sourceLocation << " ";
		        out1 << tempInt->effect << " ";
		        out1 << tempInt->typeOfInteraction << " ";
		        out1 << tempInt->pmid << endl;
                        tempInt->flag = 1;
                  }
            }
      }
      else if (howDeep > sizeWeLookFor)
      {
            return;
      }
      else
      {
            for (int i = 0; i < tempNode->linksCount; i++)
            {     
                  localNode = GetNodeBasedOnNumber(tempNode->linksTo[i]);
 
                  if (NotAlreadyInList(listSoFar, howDeep, localNode->number) 
				  && (DirectionOK(tempNode, localNode)))
                  {
                        listSoFar[howDeep] = localNode->number;
                        CountNumberOfPathwaysToOutputAndDump(out1, 
					targetName, localNode, sizeWeLookFor, 
                                        howDeep + 1, listSoFar);
                  }
            }
      }     
}
