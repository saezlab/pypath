#!/usr/bin/env python2
# -*- coding: utf-8 -*-

# try:
import __main__ as ext
from bioigraph import BioGraph
from descriptions import *


    #__all__ = ["pwnet", "mapping", "log", "oset"]
#if __name__ != '__main__':
#    from _common import *  # defines __all__
    #__all__ = _import_package_files()
    # print __all__
    # __all__.remove('__all__')  # prevent self export (optional)
#__all__ = ["pwnet", "mapping", "oset", "igraph", "_mysql", "sys", "os", "string", "random", "datetime", "pickle", "chain", "logging", "log", "codecs", "csv" ]
#except ImportError:
    #sys.stdout.write('''\n\t::: Some modules are missing, or \n
        #can not be loaded. Please install them, and try again.\n
        #Linux or OS X:\n
        ## pip2 install <module>\n
        #Windows:\n
        #C:\> python -m pip install <module>\n\n''')
